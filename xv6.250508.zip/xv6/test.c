#include "types.h"
#include "stat.h"
#include "user.h"
#include "pstat.h"

int
main(void)
{
  struct pstat ps;

  // ✅ 1. MLFQ 정책으로 설정
  setSchedPolicy(1);  // 0 = RR, 1 = MLFQ

  // ✅ 2. 자식 3개 생성해서 CPU 쓰게 하기
  for (int i = 0; i < 3; i++) {
    int pid = fork();
    if (pid == 0) {
      while(1);  // 자식: 무한 루프 (CPU 소모 → priority 내려감)
    }
  }

  // ✅ 3. 어느 정도 시간 주고
  sleep(200);

  // ✅ 4. 상태 정보 받아오기
  if (getpinfo(&ps) < 0) {
    printf(1, "getpinfo failed\n");
    exit();
  }

  // ✅ 5. 상태 출력
  for (int i = 0; i < NPROC; i++) {
    if (ps.inuse[i]) {
      printf(1, "PID %d | prio: %d | q3:%d q2:%d q1:%d q0:%d\n",
             ps.pid[i], ps.priority[i],
             ps.ticks[i][3], ps.ticks[i][2],
             ps.ticks[i][1], ps.ticks[i][0]);
    }
  }

  // ✅ 6. 자식들 정리
  for (int i = 0; i < 3; i++)
    wait();

  exit();
}

