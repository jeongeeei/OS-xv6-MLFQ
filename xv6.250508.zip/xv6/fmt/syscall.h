3550 // System call numbers
3551 #define SYS_fork    1
3552 #define SYS_exit    2
3553 #define SYS_wait    3
3554 #define SYS_pipe    4
3555 #define SYS_read    5
3556 #define SYS_kill    6
3557 #define SYS_exec    7
3558 #define SYS_fstat   8
3559 #define SYS_chdir   9
3560 #define SYS_dup    10
3561 #define SYS_getpid 11
3562 #define SYS_sbrk   12
3563 #define SYS_sleep  13
3564 #define SYS_uptime 14
3565 #define SYS_open   15
3566 #define SYS_write  16
3567 #define SYS_mknod  17
3568 #define SYS_unlink 18
3569 #define SYS_link   19
3570 #define SYS_mkdir  20
3571 #define SYS_close  21
3572 #define SYS_uthread_init 22
3573 
3574 
3575 
3576 
3577 
3578 
3579 
3580 
3581 
3582 
3583 
3584 
3585 
3586 
3587 
3588 
3589 
3590 
3591 
3592 
3593 
3594 
3595 
3596 
3597 
3598 
3599 
