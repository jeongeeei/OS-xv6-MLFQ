3400 #include "types.h"
3401 #include "defs.h"
3402 #include "param.h"
3403 #include "memlayout.h"
3404 #include "mmu.h"
3405 #include "proc.h"
3406 #include "x86.h"
3407 #include "traps.h"
3408 #include "spinlock.h"
3409 #include "i8254.h"
3410 
3411 
3412 // Interrupt descriptor table (shared by all CPUs).
3413 struct gatedesc idt[256];
3414 extern uint vectors[];  // in vectors.S: array of 256 entry pointers
3415 struct spinlock tickslock;
3416 uint ticks;
3417 
3418 void
3419 tvinit(void)
3420 {
3421   int i;
3422 
3423   for(i = 0; i < 256; i++)
3424     SETGATE(idt[i], 0, SEG_KCODE<<3, vectors[i], 0);
3425   SETGATE(idt[T_SYSCALL], 1, SEG_KCODE<<3, vectors[T_SYSCALL], DPL_USER);
3426 
3427   initlock(&tickslock, "time");
3428 }
3429 
3430 void
3431 idtinit(void)
3432 {
3433   lidt(idt, sizeof(idt));
3434 }
3435 
3436 
3437 
3438 
3439 
3440 
3441 
3442 
3443 
3444 
3445 
3446 
3447 
3448 
3449 
3450 void
3451 trap(struct trapframe *tf)
3452 {
3453   if(tf->trapno == T_SYSCALL){
3454     if(myproc()->killed)
3455       exit();
3456     myproc()->tf = tf;
3457     syscall();
3458     if(myproc()->killed)
3459       exit();
3460     return;
3461   }
3462 
3463   switch(tf->trapno){
3464   case T_IRQ0 + IRQ_TIMER:
3465     if(cpuid() == 0){
3466       acquire(&tickslock);
3467       ticks++;
3468       wakeup(&ticks);
3469       release(&tickslock);
3470     }
3471     lapiceoi();
3472 
3473     if (myproc() && myproc()->scheduler){
3474         myproc()->tf->eip = myproc()->scheduler;
3475     }
3476 
3477     break;
3478   case T_IRQ0 + IRQ_IDE:
3479     ideintr();
3480     lapiceoi();
3481     break;
3482   case T_IRQ0 + IRQ_IDE+1:
3483     // Bochs generates spurious IDE1 interrupts.
3484     break;
3485   case T_IRQ0 + IRQ_KBD:
3486     kbdintr();
3487     lapiceoi();
3488     break;
3489   case T_IRQ0 + IRQ_COM1:
3490     uartintr();
3491     lapiceoi();
3492     break;
3493   case T_IRQ0 + 0xB:
3494     i8254_intr();
3495     lapiceoi();
3496     break;
3497   case T_IRQ0 + IRQ_SPURIOUS:
3498     cprintf("cpu%d: spurious interrupt at %x:%x\n",
3499             cpuid(), tf->cs, tf->eip);
3500     lapiceoi();
3501     break;
3502 
3503 
3504   default:
3505   /* in case for pagefault
3506     #define MAX_STACK_SIZE (8 * 1024 * 1024) // 8MB stack
3507 
3508     uint addr = rcr2();
3509 
3510     if (KERNBASE - addr > MAX_STACK_SIZE) {
3511       cprintf("trap: stack limit exceeded at 0x%x\n", addr);
3512       myproc()->killed = 1;
3513       break;
3514       }
3515   */
3516     if(myproc() == 0 || (tf->cs&3) == 0){
3517       // In kernel, it must be our mistake.
3518       cprintf("unexpected trap %d from cpu %d eip %x (cr2=0x%x)\n",
3519               tf->trapno, cpuid(), tf->eip, rcr2());
3520       panic("trap");
3521     }
3522     // In user space, assume process misbehaved.
3523     cprintf("pid %d %s: trap %d err %d on cpu %d "
3524             "eip 0x%x addr 0x%x--kill proc\n",
3525             myproc()->pid, myproc()->name, tf->trapno,
3526             tf->err, cpuid(), tf->eip, rcr2());
3527     myproc()->killed = 1;
3528   }
3529 
3530   // Force process exit if it has been killed and is in user space.
3531   // (If it is still executing in the kernel, let it keep running
3532   // until it gets to the regular system call return.)
3533   if(myproc() && myproc()->killed && (tf->cs&3) == DPL_USER)
3534     exit();
3535 
3536   // Force process to give up CPU on clock tick.
3537   // If interrupts were on while locks held, would need to check nlock.
3538   if(myproc() && myproc()->state == RUNNING &&
3539      tf->trapno == T_IRQ0+IRQ_TIMER)
3540     yield();
3541 
3542   // Check if the process has been killed since we yielded
3543   if(myproc() && myproc()->killed && (tf->cs&3) == DPL_USER)
3544     exit();
3545 }
3546 
3547 
3548 
3549 
