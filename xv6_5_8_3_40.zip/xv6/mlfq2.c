#include "types.h"
#include "stat.h"
#include "user.h"
#include "pstat.h"

#define NCHILD 3
#define SNAPSHOT_CNT 20
#define SNAPSHOT_INTERVAL 10000000

void workload(int n) {
  int i, j = 0;
  for(i = 0; i < n; i++)
    j += i * j + 1;
}

int main(void) {
  struct pstat st;
  int pid = fork();
  if(pid == 0) {
    // 자주 yield()해서 치팅 시도
    for(int i=0; i<100; i++) {
      workload(1000000); // 짧은 작업
      yield();
    }
    exit();
  } else {
    sleep(100); // 충분히 돌게 함
    getpinfo(&st);
    for(int i=0; i<NPROC; i++) {
      if(st.pid[i] == pid) {
        printf(1, "PID %d: Priority %d, Ticks(Q3 Q2 Q1 Q0): %d %d %d %d\n",
          st.pid[i], st.priority[i],
          st.ticks[i][3], st.ticks[i][2], st.ticks[i][1], st.ticks[i][0]);
      }
    }
    wait();
    exit();
  }
}

