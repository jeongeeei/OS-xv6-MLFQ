#include "types.h"
#include "stat.h"
#include "user.h"
#include "pstat.h"

#define NCHILD 3
#define SNAPSHOT_CNT 20
#define SNAPSHOT_INTERVAL 10000000

void workload(int n) {
  int i, j = 0;
  for(i = 0; i < n; i++)
    j += i * j + 1;
}

int main(void) {
  struct pstat st;
  int pid[NCHILD];
  int i;

  setSchedPolicy(1); // MLFQ로 전환

  for(i = 0; i < NCHILD; i++) {
    pid[i] = fork();
    if(pid[i] == 0) {
      if(i == 0) {
        // Q3->Q2->Q3
        workload(8000000); sleep(20); workload(8000000); sleep(20);
      } else if(i == 1) {
        // Q3->Q2->Q1->Q2->Q3
        workload(16000000); sleep(20); workload(8000000); sleep(20);
      } else {
        // Q3->Q2->Q1->Q0->Q1->Q2->Q1->Q0
        workload(32000000); sleep(20); workload(16000000); sleep(20);
      }
      exit();
    }
  }

  sleep(200); // 충분히 돌게 함
  getpinfo(&st);
  for(i = 0; i < NPROC; i++) {
    for(int j=0; j<NCHILD; j++) {
      if(st.pid[i] == pid[j]) {
        printf(1, "PID %d: Priority %d, Ticks(Q3 Q2 Q1 Q0): %d %d %d %d\n",
          st.pid[i], st.priority[i],
          st.ticks[i][3], st.ticks[i][2], st.ticks[i][1], st.ticks[i][0]);
      }
    }
  }
  for(i = 0; i < NCHILD; i++)
    wait();
  exit();
}
