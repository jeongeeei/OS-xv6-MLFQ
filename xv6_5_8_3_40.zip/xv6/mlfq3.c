#include "types.h"
#include "stat.h"
#include "user.h"
#include "pstat.h"

#define NCHILD 3
#define SNAPSHOT_CNT 20
#define SNAPSHOT_INTERVAL 10000000

void workload(int n) {
  int i, j = 0;
  for(i = 0; i < n; i++)
    j += i * j + 1;
}

int main(void) {
  struct pstat st;
  int pid = fork();
  if(pid == 0) {
    // 일부러 Q0까지 떨어지게 한 뒤, sleep으로 대기
    workload(50000000); // 충분히 큐 강등 유도
    sleep(600);         // Q0에서 500틱 이상 대기
    exit();
  } else {
    sleep(700); // 자식이 부스팅될 때까지 대기
    getpinfo(&st);
    for(int i=0; i<NPROC; i++) {
      if(st.pid[i] == pid) {
        printf(1, "PID %d: Priority %d, Wait_ticks(Q3 Q2 Q1 Q0): %d %d %d %d\n",
          st.pid[i], st.priority[i],
          st.wait_ticks[i][3], st.wait_ticks[i][2], st.wait_ticks[i][1], st.wait_ticks[i][0]);
      }
    }
    wait();
    exit();
  }
}
