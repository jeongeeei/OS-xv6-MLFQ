#include "param.h"
struct pstat {//유저프로그램, getpinfo 실행시 커널에서 프로세스의 현 상태를 저장하고 유저 공간에 전달, 반환값은 성공시 0, 실패시 -1
  // whether this slot of the process table is in use (1 or 0)
  int inuse[NPROC];  //현재 사용중인지 0사용, 1 빈공간
  // PID of each process
  int pid[NPROC];    //
  // current priority level of each process (0-3)
  int priority[NPROC];  //0부터 3까지의 우선순위(큐번호)
  // current state (e.g., SLEEPING or RUNNABLE) of each process
  // see enum procstate
  int state[NPROC];  //현 상태 저장
  // number of ticks each process has accumulated 
  // RUNNING/SCHEDULED at each of 4 priorities
  int ticks[NPROC][4];  //프로세스 누적 수행시간
  // number of ticks each process has waited before being scheduled
  int wait_ticks[NPROC][4]; //프로세스 대기 시간
};

